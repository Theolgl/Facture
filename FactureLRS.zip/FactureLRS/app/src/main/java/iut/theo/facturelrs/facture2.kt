package iut.theo.facturelrs

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun InvoiceResultScreen(quantity: Int?, unitPrice: Float?, taxRate: Float?, discount: Float?) {

    var totalAmount: Float?
    var subTotal: Float?

    subTotal = quantity!! * unitPrice!!

    totalAmount = subTotal + subTotal * taxRate!! / 100 - subTotal * discount!! / 100

    Column {
        Text(text = "Montant Total: $totalAmount")
        Button(onClick = { /* Retour à l'écran précédent */ }) {
            Text("Retour")
        }
    }
}
