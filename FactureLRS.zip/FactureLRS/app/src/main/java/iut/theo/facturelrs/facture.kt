package iut.theo.facturelrs

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.navigation.NavHostController

@Composable
fun InvoiceScreen(navController: NavHostController) {
    var quantity by remember { mutableStateOf("") }
    var unitPrice by remember { mutableStateOf("") }
    var taxRate by remember { mutableStateOf("") }
    var discount by remember { mutableStateOf("") }
    var isLoyalCustomer by remember { mutableStateOf("") }

    Column {
        TextField(
            value = quantity,
            onValueChange = { quantity = it },
            label = { Text("Quantité") }
        )
        TextField(value = unitPrice, onValueChange = { unitPrice = it }, label = { Text("Prix unitaire") })
        TextField(value = taxRate, onValueChange = { taxRate = it }, label = { Text("Taux TVA") })

        Button(onClick = { /* Calculer TTC */ }) {
            navController.navigate()
            Text("Calculer TTC")
        }

        Button(onClick = {
            navController.navigate("total/{$quantity}/{$unitPrice}/{$taxRate}/{$discount}")
        }) {
            Text("Remise A Zero")
        }
    }
}

private fun NavHostController.navigate() {
    TODO("Not yet implemented")
}

@Composable
fun CustomRadioButton(selected: Any, onClick: () -> Unit) {
    // À compléter avec la logique de bouton radio personnalisée
}
