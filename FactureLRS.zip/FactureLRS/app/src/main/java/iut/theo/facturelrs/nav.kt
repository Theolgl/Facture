package iut.theo.facturelrs

import androidx.compose.runtime.Composable
import androidx.navigation.NavHost
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.navArgument

@Composable
fun Nav() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "facture")  {
        composable("facture") {
            FactureScreen(navController)
        }



        composable(
            "total/{qte1}/{pu1}/{tva1}/{remise1}",
            arguments = listOf(
                navArgument(name = "qte1") {
                    type = NavType.IntType
                },
                navArgument(name = "pu1") {
                    type = NavType.FloatType
                },
                navArgument(name = "tva1") {
                    type = NavType.FloatType
                },
                navArgument(name = "remise1") {
                    type = NavType.FloatType
                },
            )
        )
        { backstraEntry ->
            ResultScreen(
                qte = backstraEntry.arguments?.getInt("qte1"),
                pu = backstraEntry.arguments?.getFloat("pu1"),
                tva = backstraEntry.arguments?.getFloat("tva1"),
                remise = backstraEntry.arguments?.getFloat("remise1")
            )
        }
    }
}

@Composable
fun FactureScreen(navController: NavHostController) {
    TODO("Not yet implemented")
}

fun composable(s: String, function: (Any?) -> Unit) {
    TODO("Not yet implemented")
}

fun rememberNavController(): NavHostController {

}
