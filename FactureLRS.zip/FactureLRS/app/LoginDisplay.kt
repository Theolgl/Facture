
@Composable
fun loginDisplay(navController: NavHostController){
    val modifier = Modifier
    Column(
        modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ){
        var loginValue by remember {
            mutableStateOf("")
        }
        var mdpValue by remember {
            mutableStateOf("")
        }
        Text(text="Authentification", fontSize = 40.sp, fontWeight = FontWeight.Bold, color = Color.Red)
        Spacer(
            modifier
                .height(75.dp)
                .fillMaxSize()
        )
        Text(text = "Votre login", fontSize = 15.sp)
        TextField(
            value = loginValue,
            onValueChange = { loginValue=it},
            modifier.padding(5.dp),
            placeholder = {Text("Login...")})
        Spacer(modifier.height(20.dp))
        TextField(
            value = mdpValue,
            onValueChange = { mdpValue=it},
            modifier.padding(5.dp),
            placeholder = {Text("Mot de passe...")})
        Button(onClick = { navController.navigate("accueil/$loginValue/$mdpValue") }) {
            Text(text = "Valider", fontSize=17.sp )
        }
    }
}